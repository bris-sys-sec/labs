<?php /* Smarty version 2.6.19, created on 2011-08-14 12:05:25
         compiled from footer.tpl */ ?>

			</div> 		</div> 

 <div id = "msgchk" style="display:none;"></div>
<script type  = "text/javascript">
		chkChat();
</script>


	<div id="footer-wrapper">
		<div class="footer">
			<div class="footer-in">
				<a href="http://collabtive.o-dyn.de">Collabtive <?php echo $this->_tpl_vars['myversion']; ?>
</a>
			</div>
		</div>
	</div>

</body>
</html>