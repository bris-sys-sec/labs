<?php
$db_host = 'localhost';

$db_name = 'sql_collabtive_db';

$db_user = 'root';

$db_pass = 'seedubuntu';

?>