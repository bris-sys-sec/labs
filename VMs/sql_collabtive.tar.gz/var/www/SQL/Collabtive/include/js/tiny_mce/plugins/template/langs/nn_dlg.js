tinyMCE.addI18n('nn.template_dlg',{
title:"Malar",
label:"Mal",
desc_label:"Omtale",
desc:"Set inn f\u00F8rehandsdefinert malinnhald",
select:"Vel ein mal",
preview:"Sj\u00E5 f\u00F8rebels utkast",
warning:"\u00C5tvaring: Utskifting av ein mal med ein annen kan f\u00F8re til at data g\u00E5r tapt.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"januar,februar,mars,april,mai,juni,juli,august,september,oktober,november,desember",
months_short:"jan,feb,mar,apr,mai,jun,jul,aug,sep,okt,nov,des",
day_long:"sundag,mandag,tirsdag,onsdag,torsdag,fredag,laurdag,sundag",
day_short:"sun,man,tir,ons,tor,fre,l\u00F8r,sun"
});